# py-confluent
Bringing KSQL, Kafka Streams, Schema Registry APIs to Python 3,
all in one clean package.

### Install

`pip install pyconfluent`

### Usage

pyconfluent requires the underlying Kafka services to be running. The 
easiest way is to start Confluent Platform, see: ``.

### KSQL

```
import KSQL

client = KSQL()  # enter your boostrap_server here if not 'localhost', no port
client.  

```
