"""
Run time exception thrown by winton kafka streams on error

"""


class KafkaStreamsError(RuntimeError):
    pass
