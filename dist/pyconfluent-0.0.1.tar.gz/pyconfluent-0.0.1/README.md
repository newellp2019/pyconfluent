# py-confluent
Bringing Confluent's KSQL, Kafka Streams, Schema Registry APIs to Python 3,
all in one clean package.