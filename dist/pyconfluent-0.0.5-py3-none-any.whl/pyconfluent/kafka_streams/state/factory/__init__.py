# TODO replace this Java-esque factory with a Pythonic DSL as part of the other work on a Streams DSL
