"""
Run time exception thrown on error
"""


class KafkaStreamsError(RuntimeError):
    pass
